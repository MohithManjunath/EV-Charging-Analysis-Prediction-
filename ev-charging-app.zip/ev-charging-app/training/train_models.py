import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

# -----------------------------
# Load Data
# -----------------------------
df = pd.read_csv("../data/ev_charging_data.csv")

# -----------------------------
# Feature Engineering
# -----------------------------
df["Energy_Needed"] = (
    df["Battery Capacity (kWh)"] *
    (100 - df["State of Charge (Start %)"]) / 100
)

X = df[
    ["Energy_Needed", "Vehicle Model", "Charger Type", "User Type"]
]

y_cost = df["Charging Cost (USD)"]
y_time = df["Charging Duration (hours)"]

# -----------------------------
# Preprocessing
# -----------------------------
cat_features = ["Vehicle Model", "Charger Type", "User Type"]
num_features = ["Energy_Needed"]

preprocessor = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_features),
        ("num", "passthrough", num_features)
    ]
)

# -----------------------------
# Cost Model
# -----------------------------
cost_pipeline = Pipeline(
    steps=[
        ("preprocessor", preprocessor),
        ("model", RandomForestRegressor(
            n_estimators=200,
            random_state=42
        ))
    ]
)

X_train, X_test, y_train_cost, y_test_cost = train_test_split(
    X, y_cost, test_size=0.2, random_state=42
)

cost_pipeline.fit(X_train, y_train_cost)

joblib.dump(cost_pipeline, "../models/cost_model.pkl")

# -----------------------------
# Time Model
# -----------------------------
time_pipeline = Pipeline(
    steps=[
        ("preprocessor", preprocessor),
        ("model", RandomForestRegressor(
            n_estimators=200,
            random_state=42
        ))
    ]
)

time_pipeline.fit(X_train, y_time.loc[X_train.index])

joblib.dump(time_pipeline, "../models/time_model.pkl")

# -----------------------------
# Driving Efficiency (No ML)
# -----------------------------
efficiency = (
    df.groupby("Vehicle Model")
    ["Distance Driven (since last charge) (km)"]
    .sum()
    /
    df.groupby("Vehicle Model")["Energy Consumed (kWh)"].sum()
)

joblib.dump(efficiency.to_dict(), "../models/vehicle_efficiency.pkl")

print("✅ Models trained and saved successfully")
